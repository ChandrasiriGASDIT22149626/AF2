import axios from 'axios'

const baseUrl = 'https://restcountries.com/v3.1'


export const getAllCountries =() => 
    axios.get(`${baseUrl}/all`);

export const getCountryByName = (name) => 
    axios.get(`${baseUrl}/name/${name}`);

export const getCountriesByRegion = (region) => 
    axios.get(`${baseUrl}/region/${region}`);

export const getCountryByCode = (code) => 
    axios.get(`${baseUrl}/alpha/${code}`);

export const getCountriesByCapitalCity = (capital) => 
    axios.get(`${baseUrl}/capital/${capital}`);

export const getCountriesByCodes = (codes) => {
    return axios.get(`${baseUrl}/alpha?codes=${codes.join(',')}`);
  };

  export async function getWikipediaSummary(title) {
    try {
      const response = await fetch(
        `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`
      );
      if (!response.ok) throw new Error('Wikipedia data not found');
      return await response.json();
    } catch (error) {
      console.error('Error fetching Wikipedia data:', error);
      return null;
    }
  }
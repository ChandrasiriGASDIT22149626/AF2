export default function FilterBar({ regions, selected, onChange }) {
    return (
      <select value={selected} onChange={(e) => onChange(e.target.value)} className="p-2 border rounded-md shadow">
        <option value="">All Regions</option>
        {regions.map((region) => (
          <option key={region} value={region}>{region}</option>
        ))}
      </select>
    );
  }
  
import { Link } from 'react-router-dom';

export default function CountryCard({ country }) {
  return (
    <Link to={`/country/${country.cca3}`}>
      <div className="border rounded-md p-4 shadow hover:shadow-lg">
        <img src={country.flags.svg} alt={country.name.common} className="h-40 w-full object-cover mb-2 rounded" />
        <h2 className="text-xl font-bold">{country.name.common}</h2>
        <p><strong>Capital:</strong> {country.capital?.[0]}</p>
        <p><strong>Region:</strong> {country.region}</p>
        <p><strong>Population:</strong> {country.population.toLocaleString()}</p>
      </div>
    </Link>
  );
}

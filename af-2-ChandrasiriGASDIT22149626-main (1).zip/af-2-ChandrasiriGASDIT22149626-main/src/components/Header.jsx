import React from 'react';
import { Link } from 'react-router-dom';
import { useSession } from '../context/SessionContext';

const Header = () => {
  const { user, login, logout } = useSession();
  const { toggleDarkMode, darkMode } = useSession();

  const handleAuthClick = () => {
    if (user) {
      logout();
    } else {
      const username = prompt('Enter your username:');
      if (username) {
        login(username);
      }
    }
  };

  return (
    <header className="bg-gray-800 text-white px-6 py-4 flex justify-between items-center">
      <nav className="flex space-x-6">
        <Link to="/" className="hover:text-gray-300 font-semibold">
          Home
        </Link>
        <Link to="/favorites" className="hover:text-gray-300 font-semibold">
          Favorites
        </Link>
      </nav>
      <button
        onClick={toggleDarkMode}
        className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition"
      >
        {darkMode ? 'Light Mode' : 'Dark Mode'}
      </button>
      <button
        onClick={handleAuthClick}
        className="bg-gray-600 hover:bg-gray-700 text-white font-semibold py-2 px-4 rounded"
      >
        {user ? 'Logout' : 'Login'}
      </button>
    </header>
  );
};

export default Header;

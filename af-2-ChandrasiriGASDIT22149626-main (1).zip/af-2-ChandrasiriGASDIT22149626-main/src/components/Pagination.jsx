// src/components/Pagination.jsx
import React from 'react';
import prevButton from '../assets/icons/prevButton.png';
import nextButton from '../assets/icons/nextButton.png'; 

const Pagination = ({ countriesPerPage, totalCountries, currentPage, paginate }) => {
  const totalPages = Math.ceil(totalCountries / countriesPerPage);

  const pageNumbers = [];
  for (let i = 1; i <= totalPages; i++) {
    pageNumbers.push(i);
  }

  const handlePrev = () => {
    if (currentPage > 1) paginate(currentPage - 1);
  };

  const handleNext = () => {
    if (currentPage < totalPages) paginate(currentPage + 1);
  };

  return (
    <div className="flex justify-center items-center mt-6 space-x-2">
      <button
        onClick={handlePrev}
        disabled={currentPage === 1}
        className="px-3 py-1  rounded "
      >
       <img src={prevButton} alt="Previous" className='w-8 h-8 cursor-pointer'/>
      </button>

      {pageNumbers.map((number) => (
        <button
          key={number}
          onClick={() => paginate(number)}
          className={`px-4 py-2 rounded ${
            currentPage === number ? 'bg-blue-600 text-white' : 'bg-gray-200'
          }`}
        >
          {number}
        </button>
      ))}

      <button
        onClick={handleNext}
        disabled={currentPage === totalPages}
        className="px-3 py-1  rounded "
      >
        <img src={nextButton} alt="Next" className='w-8 h-8 cursor-pointer '/>
      </button>
    </div>
  );
};

export default Pagination;

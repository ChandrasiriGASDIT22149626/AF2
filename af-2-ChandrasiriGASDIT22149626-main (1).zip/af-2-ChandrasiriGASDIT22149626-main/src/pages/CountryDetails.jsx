import { useParams, useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { getCountryByCode, getCountriesByCodes, getWikipediaSummary } from '../services/countryService';
import { useSession } from '../context/SessionContext';

export default function CountryDetails() {
  const { code } = useParams();
  const navigate = useNavigate();
  const [country, setCountry] = useState(null);
  const [borders, setBorders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [wikipediaData, setWikipediaData] = useState(null); 
  const { user, addFavorite, removeFavorite, isFavorite } = useSession();

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const response = await getCountryByCode(code);
        if (response.data.length === 0) throw new Error('Country not found');

        const countryData = response.data[0];
        setCountry(countryData);

        const wikiData = await getWikipediaSummary(countryData.name.common);
        setWikipediaData(wikiData);

        if (countryData.borders?.length > 0) {
          const bordersResponse = await getCountriesByCodes(countryData.borders);
          setBorders(bordersResponse.data);
        }
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [code]);

  const handleToggleFavorite = () => {
    if (!country) return;
    const isFav = isFavorite(country.cca3);
    isFav ? removeFavorite(country.cca3) : addFavorite(country);
  };

  if (loading) return <div className="p-4 text-center">Loading country data...</div>;
  if (error) return <div className="p-4 text-center text-red-500">{error}</div>;
  if (!country) return <div className="p-4 text-center">No country data available</div>;

  const isFav = isFavorite(country.cca3);

  return (
    <div className="p-4 max-w-4xl mx-auto">
      <button
        onClick={() => navigate(-1)}
        className="mb-6 px-4 py-2 bg-gray-200 rounded hover:bg-gray-300 transition"
      >
        ← Back
      </button>

      <div className="grid md:grid-cols-2 gap-8">
        <div>
          <img
            src={country.flags.svg}
            alt={`Flag of ${country.name.common}`}
            className="w-full rounded shadow-lg mb-4 border border-gray-200"
          />
        </div>

        <div>
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-3xl font-bold">{country.name.common}</h1>
            {user ? (
        <button
          onClick={handleToggleFavorite}
          className={`px-4 py-2 rounded shadow transition ${
            isFav
              ? 'bg-red-500 text-white hover:bg-red-600'
              : 'bg-green-500 text-white hover:bg-green-600'
          }`}
        >
          {isFav ? 'Remove Favorite' : 'Add to Favorites'}
        </button>
      ) : (
        <span className="text-sm text-gray-500 italic">
          Log in to add favorites
        </span>
      )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
            <div>
              <p><strong>Official Name:</strong> {country.name.official}</p>
              <p><strong>Capital:</strong> {country.capital?.join(', ') || 'N/A'}</p>
              <p><strong>Region:</strong> {country.region}</p>
              <p><strong>Subregion:</strong> {country.subregion || 'N/A'}</p>
            </div>
            <div>
              <p><strong>Population:</strong> {country.population.toLocaleString()}</p>
              <p><strong>Area:</strong> {country.area.toLocaleString()} km²</p>
              <p><strong>Languages:</strong> {Object.values(country.languages || {}).join(', ') || 'N/A'}</p>
              <p><strong>Currency:</strong> {country.currencies ? Object.values(country.currencies).map(c => c.name).join(', ') : 'N/A'}</p>
            </div>
          </div>

          {borders.length > 0 && (
            <div>
              <h2 className="text-xl font-semibold mb-2">Border Countries</h2>
              <div className="flex flex-wrap gap-2">
                {borders.map(border => (
                  <button
                    key={border.cca3}
                    onClick={() => navigate(`/country/${border.cca3}`)}
                    className="px-3 py-1 bg-gray-100 rounded shadow hover:bg-gray-200 transition"
                  >
                    {border.name.common}
                  </button>
                ))}
              </div>
            </div>
          )}

           {/* Wikipedia Summary Section */}
           {wikipediaData && (
            <div className="mb-6 p-4 bg-gray-50 rounded-lg">
              <h2 className="text-xl font-semibold mb-2">About {country.name.common}</h2>
              <p className="mb-2">{wikipediaData.extract}</p>
              <a
                href={wikipediaData.content_urls.desktop.page}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline"
              >
                Read more on Wikipedia →
              </a>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}

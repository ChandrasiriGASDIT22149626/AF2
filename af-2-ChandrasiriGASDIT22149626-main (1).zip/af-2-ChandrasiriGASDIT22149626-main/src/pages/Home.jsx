import { useEffect, useState } from 'react';
import { getAllCountries, getCountriesByRegion, getCountryByName } from '../services/countryService';
import CountryCard from '../components/CountryCard';
import SearchBar from '../components/SearchBar';
import FilterBar from '../components/FilterBar';
import Pagination from '../components/Pagination';

export default function Home() {
  const [countries, setCountries] = useState([]);
  const [search, setSearch] = useState('');
  const [region, setRegion] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [countriesPerPage] = useState(12);

  const indexOfLastCountry = currentPage * countriesPerPage;
  const indexOfFirstCountry = indexOfLastCountry - countriesPerPage;
  const currentCountries = countries.slice(indexOfFirstCountry, indexOfLastCountry);

  const handlePaginate = (pageNumber) => setCurrentPage(pageNumber);

  useEffect(() => {
    const fetchCountries = async () => {
        try {
          if (search) {
            const res = await getCountryByName(search);
            setCountries(res.data);
          } else if (region) {
            const res = await getCountriesByRegion(region);
            setCountries(res.data);
          } else {
            const res = await getAllCountries();
            setCountries(res.data);
          }
          setCurrentPage(1); // Reset to first page on new search/filter
        } catch (err) {
          setCountries([]);
        }
      };
      fetchCountries();
  }, [search, region]);

  const regions = ['Africa', 'Americas', 'Asia', 'Europe', 'Oceania'];

  return (
    <div className="p-4">

      <div className="flex flex-col sm:flex-row gap-4 mb-4">
        <SearchBar value={search} onChange={setSearch} />
        <FilterBar regions={regions} selected={region} onChange={setRegion} />
      </div>

      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        {currentCountries.map((country) => (
          <CountryCard key={country.cca3} country={country} />
        ))}
      </div>

      <Pagination
        countriesPerPage={countriesPerPage}
        totalCountries={countries.length}
        currentPage={currentPage}
        paginate={handlePaginate}
      />
      </div>

   
  );
}

import { useSession } from '../context/SessionContext';
import CountryCard from '../components/CountryCard';

export default function Favorites() {
  const { favorites } = useSession();

  if (favorites.length === 0) return <p className="p-4">No favorite countries yet.</p>;

  return (
    <div className="p-4">
      <h2 className="text-2xl font-semibold mb-4">Your Favorite Countries</h2>
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        {favorites.map((country) => (
          <CountryCard key={country.cca3} country={country} />
        ))}
      </div>
    </div>
  );
}

import { createContext, useContext, useState, useEffect } from 'react';

const SessionContext = createContext();

export const SessionProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [favorites, setFavorites] = useState([]);
  const [darkMode, setDarkMode] = useState(false);

  // Load user, favorites, and darkMode from localStorage on mount
  useEffect(() => {
    const savedUser = JSON.parse(localStorage.getItem('user'));
    const savedFavorites = JSON.parse(localStorage.getItem('favorites')) || [];
    const savedDarkMode = JSON.parse(localStorage.getItem('darkMode')) || false; // Get dark mode state

    if (savedUser) setUser(savedUser);
    setFavorites(savedFavorites);
    setDarkMode(savedDarkMode); // Set dark mode from localStorage
  }, []);

  // Save favorites to localStorage on change
  useEffect(() => {
    localStorage.setItem('favorites', JSON.stringify(favorites));
  }, [favorites]);

  // Save user to localStorage on change
  useEffect(() => {
    if (user) {
      localStorage.setItem('user', JSON.stringify(user));
    } else {
      localStorage.removeItem('user');
    }
  }, [user]);

  // Save darkMode to localStorage on change
  useEffect(() => {
    localStorage.setItem('darkMode', JSON.stringify(darkMode)); // Save dark mode to localStorage

    // Apply dark mode to the body element when darkMode state changes
    if (darkMode) {
      document.body.classList.add('dark');
    } else {
      document.body.classList.remove('dark');
    }
  }, [darkMode]);

  const login = (username) => setUser({ name: username });
  const logout = () => {
    setUser(null);
    setFavorites([]);
  };

  const toggleDarkMode = () => setDarkMode((prev) => !prev); // Toggle dark mode

  const addFavorite = (country) => {
    if (!user) {
      alert('You must be logged in to add favorites.');
      return;
    }

    if (!favorites.find((c) => c.cca3 === country.cca3)) {
      setFavorites([...favorites, country]);
    }
  };

  const removeFavorite = (countryCode) => {
    setFavorites(favorites.filter((c) => c.cca3 !== countryCode));
  };

  const isFavorite = (countryCode) => {
    return favorites.some((c) => c.cca3 === countryCode);
  };

  return (
    <SessionContext.Provider
      value={{
        user,
        favorites,
        login,
        logout,
        addFavorite,
        removeFavorite,
        isFavorite,
        darkMode,
        toggleDarkMode,
      }}
    >
      {children}
    </SessionContext.Provider>
  );
};

export const useSession = () => useContext(SessionContext);

[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/mNaxAqQD)


[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/mNaxAqQD)

Countries App – Detailed Project Description
 Project Objective:
The Countries App is designed to provide users with quick and detailed information about countries around the world. It aims to help students, travelers, and general users to easily explore geographic and demographic data through a modern and interactive user interface.

 Target Users:
School and university students

Travelers and tourists

Anyone interested in learning about countries

 Technologies Used:
Technology	Purpose
Vite	Frontend tool for fast development and optimized builds
JavaScript / React	To handle the dynamic rendering of data
HTML & CSS	For building and styling the UI
REST Countries API (if used)	To fetch real-time country data
VS Code	Code editor used for development

 Key Functionalities:
Home Page:

Displays a welcome message or country list

May include a brief description of the app

Country List View:

Shows a grid/list of all countries

Includes flag, name, and region

Search Feature:

Users can type to search countries by name

Real-time filtering improves usability

Country Detail View:

On clicking a country, shows:

Capital

Population

Currency

Official language

Flag image

Region and subregion

Responsive Design:

Works on desktops, tablets, and phones

Fast Load Time:

Thanks to Vite’s development server and build optimization